.CoefFitDynr <- function(x) {
  return(
    x@transformed.parameters
  )
}
