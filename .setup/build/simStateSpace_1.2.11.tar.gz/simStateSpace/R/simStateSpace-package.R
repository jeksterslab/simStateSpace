#' @aliases simStateSpace-package
#' @keywords internal
"_PACKAGE"

## usethis namespace: start
#' @importFrom Rcpp sourceCpp
#' @useDynLib simStateSpace, .registration = TRUE
## usethis namespace: end
NULL
