# simStateSpace 1.0.1.9000

* Latest development version.
* Added functions to generate data for models with covariates.
* Added functions to generate data for linear growth curve models.

# simStateSpace 1.0.1

* Updates to package documentation.

# simStateSpace 1.0.0

* Initial release.
