# simStateSpace 1.0.1.9000

* Latest development version.
* Added functions to generate models with covariates.

# simStateSpace 1.0.1

* Updates to package documentation.

# simStateSpace 1.0.0

* Initial release.
