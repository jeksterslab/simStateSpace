# simStateSpace 1.2.1

* [LinSDE2SSM()] can now accept a matrix of zeros for the argument `sigma_l`.

# simStateSpace 1.2.0

* Added functions to generate linear stochastic differential equation models.

# simStateSpace 1.1.0

* Added functions to generate data for models with covariates.
* Added functions to generate data for linear growth curve models.
* Added `print`, `as.data.frame`, `as.matrix`, and `plot` methods.

# simStateSpace 1.0.1

* Updates to package documentation.

# simStateSpace 1.0.0

* Initial release.
