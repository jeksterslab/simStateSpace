library(testthat)
library(simStateSpace)

test_check("simStateSpace")
